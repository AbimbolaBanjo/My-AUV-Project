import serial
import time
import logging
import os
from fastapi import FastAPI
from pydantic import BaseModel

# Initialize FastAPI app
app = FastAPI()

# Set up logging
logging.basicConfig(level=logging.INFO)

# Define a model for Xbox input data
class XboxInput(BaseModel):
    button: str
    value: int

# Function to find the first available USB serial device (ttyUSB* or ttyACM*)
def find_serial_port():
    for device in os.listdir('/dev'):
        if device.startswith('ttyUSB') or device.startswith('ttyACM'):
            return os.path.join('/dev', device)
    return None

# Function to establish serial connection
def establish_serial_connection():
    arduino_port = find_serial_port()
    if arduino_port is None:
        logging.error("No serial device found.")
        return None
    
    try:
        # Open the serial port with the detected device
        ser = serial.Serial(arduino_port, 115200, timeout=1)
        time.sleep(2)  # Give time for the serial connection to establish
        logging.info(f"Serial connection established with {arduino_port}.")
        return ser
    except serial.SerialException as e:
        logging.error(f"Error opening serial port {arduino_port}: {e}")
        return None

# Initialize serial connection
ser = establish_serial_connection()

@app.post("/xbox_input/")
async def receive_xbox_input(input_data: XboxInput):
    global ser
    
    # Check if the serial connection is active
    if ser is None or not ser.is_open:
        logging.warning("Serial connection lost. Attempting to reconnect...")
        ser = establish_serial_connection()
        if ser is None:
            return {"message": "Failed to reconnect to Arduino.", "error": "Serial connection not found."}

    try:
        # Process the input (can be controlling pumps, servos, etc.)
        logging.info(f"Received Xbox input: Button={input_data.button}, Value={input_data.value}")

        # Sending the button and value to the Arduino via serial communication
        message = f"{input_data.button}:{input_data.value}\n"
        try:
            ser.write(message.encode())  # Send data to Arduino
            logging.info(f"Sent to Arduino: {message.strip()}")
        except Exception as e:
            logging.error(f"Error sending data to Arduino: {e}")

        return {"message": "Input received successfully"}
    except Exception as e:
        logging.error(f"Error processing Xbox input: {e}")
        return {"message": "Failed to process input", "error": str(e)}

if __name__ == "__main__":
    import uvicorn
    try:
        uvicorn.run(app, host="0.0.0.0", port=8002)
    except Exception as e:
        logging.error(f"Error starting FastAPI server: {e}")

