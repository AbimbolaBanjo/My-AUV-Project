from fastapi import FastAPI, Request, status
from fastapi.templating import Jinja2Templates
from fastapi.responses import StreamingResponse
import os
from picamera2 import Picamera2

# Initialize Picamera2
picam2 = Picamera2()

# Set desired resolution (e.g., 640x480 or 1920x1080)
picam2.configure(picam2.create_preview_configuration(main={"format": 'XRGB8888', "size": (640, 480)}))

# Start the camera
picam2.start()

app = FastAPI(title="Video Streaming")
templates = Jinja2Templates(directory="templates")

def generate_video_chunks():
    while True:
        # Capture frame from the camera
        frame = picam2.capture_array()
        
        # Here, you can process the frame if needed (e.g., encode to JPEG, H264, etc.)
        # For simplicity, we will stream the raw frame
        print("Captured Frame")
        
        # To simulate video streaming, you'd typically encode frames (using OpenCV or a similar library)
        # In this example, we're assuming you have a function to yield frames for streaming.
        # Yielding a mock video chunk here (in practice, you need encoding for proper streaming)
        yield frame.tobytes()

@app.get("/")
async def home(request: Request):
    return templates.TemplateResponse(
        "index.html", context={"request": request, "title": "FastAPI Video Streaming"}
    )

@app.get("/stream-video")
async def stream_video(request: Request):
    return StreamingResponse(
        content=generate_video_chunks(),
        status_code=status.HTTP_200_OK,
        media_type="video/x-mjpeg",  # MJPEG is a common format for video streaming
    )

