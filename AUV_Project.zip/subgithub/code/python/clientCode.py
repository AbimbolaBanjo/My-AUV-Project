import os
import evdev
import requests
from evdev import InputDevice, categorize, ecodes
import time

# Find the Xbox controller automatically
def find_xbox_controller():
    """Automatically finds the Xbox controller's event file."""
    while True:
        try:
            devices = [InputDevice(path) for path in evdev.list_devices()]
            for device in devices:
                if "Xbox" in device.name:  # Adjust this condition based on your device name
                    print(f"Connected to {device.name} at {device.path}")
                    return device
        except Exception as e:
            print(f"Error detecting Xbox controller: {e}")
        print("No Xbox controller found. Retrying in 3 seconds...")
        time.sleep(3)


# Server URL
SERVER_URL = "http://192.168.217.175:8002/xbox_input/"

# Button mappings
button_map = {
    ecodes.BTN_A: "A",
    ecodes.BTN_B: "B",
    ecodes.BTN_X: "X",
    ecodes.BTN_Y: "Y",
    ecodes.BTN_START: "START",
    ecodes.BTN_SELECT: "SELECT",
}

# Joystick mappings
joystick_map = {
    ecodes.ABS_X: "LEFT_STICK_X",
    ecodes.ABS_Y: "LEFT_STICK_Y",
}

# Function to quantize joystick values into 11 segments
def quantize_into_11_segments_index(raw_value):
    segment_ranges = [
        (-32768, -27000), (-27000, -21000), (-21000, -15000), (-15000, -9000),
        (-9000, -3000), (-3000, 3000), (3000, 9000), (9000, 15000),
        (15000, 21000), (21000, 27000), (27000, 32767)
    ]

    for i, (lower, upper) in enumerate(segment_ranges):
        if lower <= raw_value <= upper:
            return i  # Return segment index (0-10)
    return 5  # Default to middle (neutral) if out of range

# Previous states to prevent duplicate requests
previous_state = {
    "buttons": {},
    "joystick": {"H": 6, "V": 6},  # Default to neutral (6th segment)
}

# Function to send data to the server
def send_to_server(data):
    try:
        response = requests.post(SERVER_URL, json=data)
        print(f"✅ Sent: {data} | Response: {response.json()}")
    except requests.exceptions.RequestException as e:
        print(f"⚠️ Error sending data to server: {e}")



while True:

    xbox_controller = find_xbox_controller()
    try:
        # Read input from Xbox controller
        print("🎮 Listening for Xbox Controller Inputs...")
        for event in xbox_controller.read_loop():
            if event.type == evdev.ecodes.EV_KEY:  # Button events
                button = button_map.get(event.code, "UNKNOWN")
                if button != "UNKNOWN":
                    if previous_state["buttons"].get(button, -1) != event.value:
                        print(f"🔘 Button {button} {'pressed' if event.value else 'released'}")
                        previous_state["buttons"][button] = event.value
                        send_to_server({"button": button, "value": event.value})

            if event.type == evdev.ecodes.EV_ABS:  # Joystick movement
                joystick = joystick_map.get(event.code, "UNKNOWN")
                if joystick in ["LEFT_STICK_X", "LEFT_STICK_Y"]:
                    quantized_value = quantize_into_11_segments_index(event.value)
                    axis = "H" if joystick == "LEFT_STICK_X" else "V"

                    if previous_state["joystick"][axis] != quantized_value:
                        print(f"🕹️ Joystick {axis} moved to {quantized_value}")
                        previous_state["joystick"][axis] = quantized_value
                        #send_to_server({axis: quantized_value})
                        send_to_server({"button": axis, "value": quantized_value})
    except OSError as e:
        print(f"⚠️ Controller disconnected: {e}. Reconnecting...")
        time.sleep(2)  # Wait before trying to reconnect





